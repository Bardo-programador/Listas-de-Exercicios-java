/**
 * 
 */
/**
 * @author Carvalho
 *
 */
module lista_2_samuel_roberto_de_carvalho_bezerra_20221y6_rc0309 {
	requires java.desktop;
}