package lista2;
import javax.swing.JOptionPane;

public class Dialogo1 {
	// exibe um diálogo com uma mensagem
	public static void main(String[] args) {
		//Questão 15
		
		JOptionPane.showMessageDialog(null, "Testando janela de mensagem");
	}
	
}
