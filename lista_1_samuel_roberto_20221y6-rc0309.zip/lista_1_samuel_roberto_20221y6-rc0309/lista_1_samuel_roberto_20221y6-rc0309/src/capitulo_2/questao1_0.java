package capitulo_2;

public class questao1_0 {
	public static void main(String[] args) {
		//quest�o 4
		System.out.println("//Quest�o 4//");
		System.out.println("Bem-vindo, ");
		System.out.println("Samuel Roberto de Carvalho Bezerra 20221y6-rc0309");
		System.out.println("! Sauda��es!");
		System.out.println("\n");
		
		
		//Quest�o 5
		String mensagem = "Bem-vindo, Samuel Roberto de Carvalho Bezerra 20221y6-rc0309! Sauda��es!";
		System.out.println("//Quest�o 5//");
		System.out.println(mensagem);//imprime a mensagem na variavel mensagem
		System.out.println("\n");
		
		
		//Quest�o 6
		String mensagem1 = "Bem-vindo, \nSamuel Roberto de Carvalho Bezerra 20221y6-rc0309\n! Sauda��es!";
		System.out.println("//Quest�o 6//");
		System.out.println(mensagem1);//imprime a mensagem na variavel mensagem1
		System.out.println("\n");
		
		//Quest�o 9
		String nome = "Samuel Roberto de Carvalho Bezerra ";
		String matricula = "20221y6-rc0309 ";
		String hora = "14:29 10/10 ";
		String livre = "Programando em Java";
		System.out.println("//Quest�o 9//");
		System.out.printf("%s%s%s%s",nome,matricula,hora,livre);
	}//fim da main
	
}//fim da classe
