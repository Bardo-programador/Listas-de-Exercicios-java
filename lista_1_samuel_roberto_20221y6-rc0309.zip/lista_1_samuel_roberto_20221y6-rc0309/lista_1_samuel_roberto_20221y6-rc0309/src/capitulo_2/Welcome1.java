package capitulo_2;

 public class Welcome1 {
	//inicia��o do aplicativo java
	
	public static void main(String[] args) {
		//Quest�o 3
		System.out.println("//Quest�o 3//");
		System.out.println("Welcome to Java Programming");
		
		//Quest�o 7
		System.out.println("//Quest�o 7//");
		System.out.println("\tWelcome\n\tto\n\tJava\n\tProgramming");
		System.out.println("\n");
		
		//Quest�o 8
		System.out.println("//Quest�o 8//");
		System.out.println("\t\"Welcome\n\tto\n\tJava\n\tProgramming\"");
	} //fim de main
	
	
} //fim da classe Welcome1
